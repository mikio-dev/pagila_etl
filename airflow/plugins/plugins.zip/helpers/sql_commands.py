class SqlCommands:
    def __init__(self):
        pass
