from airflow.hooks.postgres_hook import PostgresHook
from airflow.hooks.S3_hook import S3Hook
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults


class S3ToRedshiftOperator(BaseOperator):
    """
    S3 to Redshift Operator

    Load a CSV file from S3 to Redshift database

    :param redshift_conn_id:      Airflow connection name for Redshift database
    :param s3_conn_id:            Airflow connection name for S3
    :param table_name:            Table name to export (e.g. customer)
    :param table_prefix:          Prefix for the table name (e.g. stg_)
    :param extract_date:          Date of the extract (e.g. 20220525)
    :param s3_bucket:             Target S3 bucket name
    :param s3_key:                Key name (file name) in the S3 bucket
    :param region_name:           AWS region name
    """

    template_fields = ("s3_bucket", "extract_date")

    @apply_defaults
    def __init__(
        self,
        redshift_conn_id="",
        s3_conn_id="",
        table_name="",
        table_prefix="",
        extract_date="",
        s3_bucket="",
        s3_key="",
        region_name="",
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.redshift_conn_id = redshift_conn_id
        self.s3_conn_id = s3_conn_id
        self.table_name = table_name
        self.table_prefix = table_prefix
        self.extract_date = extract_date
        self.s3_bucket = s3_bucket
        self.s3_key = s3_key
        self.region_name = region_name

    def execute(self, context):
        s3_hook = S3Hook(self.s3_conn_id)
        credentials = s3_hook.get_credentials()
        redshift = PostgresHook(postgres_conn_id=self.redshift_conn_id)

        # S3 file
        if self.s3_key == "":
            _s3_key = f"{self.extract_date}/{self.table_name}.csv"
        else:
            _s3_key = self.s3_key

        # _s3_path = f"s3://{credentials.access_key}:{credentials.secret_key}@{self.s3_bucket}/{_s3_key}"
        _s3_path = (
            f"http://s3.localhost.localstack.cloud:4566/{self.s3_bucket}/{_s3_key}"
        )

        # Target table name in Redshift
        _table_name = self.table_prefix + self.table_name

        # Truncate the target table
        self.log.info(f"Truncating the table {_table_name}")
        redshift.run(f"TRUNCATE {_table_name}")

        # COPY command for the upload
        copy_command = f"""
            COPY {_table_name}
            FROM '{_s3_path}'
        """

        self.log.info(f"Copying data from {_s3_path} to the table {_table_name}")
        redshift.run(copy_command)
